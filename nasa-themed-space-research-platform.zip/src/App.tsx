import { useState, useEffect } from "react";
import Navbar from "./components/Navbar";
import StarField from "./components/StarField";
import HeroSection from "./components/HeroSection";
import ResearchSection from "./components/ResearchSection";
import SpacecraftSection from "./components/SpacecraftSection";
import DictionarySection from "./components/DictionarySection";
import AboutSection from "./components/AboutSection";
import SolarSystemViz from "./components/SolarSystemViz";
import MissionControlBanner from "./components/MissionControlBanner";
import Footer from "./components/Footer";

export default function App() {
  const [activeSection, setActiveSection] = useState("home");

  useEffect(() => {
    const sections = ["home", "research", "spacecraft", "dictionary", "about"];
    const observers: IntersectionObserver[] = [];

    sections.forEach((id) => {
      const el = document.getElementById(id);
      if (!el) return;
      const observer = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting) setActiveSection(id);
        },
        { threshold: 0.3 }
      );
      observer.observe(el);
      observers.push(observer);
    });

    return () => observers.forEach((o) => o.disconnect());
  }, []);

  return (
    <div className="relative min-h-screen bg-[#020812] space-grid">
      {/* Animated starfield background */}
      <StarField />

      {/* Navbar */}
      <Navbar activeSection={activeSection} setActiveSection={setActiveSection} />

      {/* Main content */}
      <main>
        <HeroSection setActiveSection={setActiveSection} />
        <ResearchSection />
        <SpacecraftSection />
        <DictionarySection />
        <SolarSystemViz />
        <AboutSection />
      </main>

      <Footer />

      {/* Floating back-to-top */}
      <button
        onClick={() => {
          window.scrollTo({ top: 0, behavior: "smooth" });
          setActiveSection("home");
        }}
        className="fixed bottom-8 right-8 z-40 w-12 h-12 rounded-full bg-blue-700/80 border border-blue-500/50 text-white flex items-center justify-center hover:bg-blue-600 transition-all duration-300 backdrop-blur-sm shadow-lg shadow-blue-900/50 group"
        title="Back to top"
      >
        <svg className="w-5 h-5 group-hover:-translate-y-0.5 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
        </svg>
      </button>
    </div>
  );
}
