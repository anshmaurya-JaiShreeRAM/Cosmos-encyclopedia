import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

interface NavbarProps {
  activeSection: string;
  setActiveSection: (section: string) => void;
}

const navItems = [
  { id: "home", label: "Home" },
  { id: "research", label: "R&D" },
  { id: "spacecraft", label: "Spacecraft" },
  { id: "dictionary", label: "Dictionary" },
  { id: "about", label: "About" },
];

export default function Navbar({ activeSection, setActiveSection }: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const handleNav = (id: string) => {
    setActiveSection(id);
    setMenuOpen(false);
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <motion.nav
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.7, ease: "easeOut" }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-[#050d1a]/95 backdrop-blur-lg shadow-lg shadow-blue-900/20 border-b border-blue-900/30"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <button
            onClick={() => handleNav("home")}
            className="flex items-center gap-3 group"
          >
            <div className="relative w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-blue-900 flex items-center justify-center shadow-lg shadow-blue-700/30">
              <svg viewBox="0 0 24 24" className="w-6 h-6 fill-white">
                <circle cx="12" cy="12" r="4" />
                <path d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm0 18c-4.411 0-8-3.589-8-8s3.589-8 8-8 8 3.589 8 8-3.589 8-8 8z" />
                <path d="M12 6a6 6 0 000 12 6 6 0 000-12z" opacity="0.3" />
                <path d="M2 12h20M12 2c-2.761 4.03-2.761 7.97 0 12M12 2c2.761 4.03 2.761 7.97 0 12" stroke="white" strokeWidth="0.5" fill="none" />
              </svg>
            </div>
            <div className="flex flex-col leading-none">
              <span className="font-['Orbitron'] text-white font-bold text-sm tracking-widest">SPACEVERSE</span>
              <span className="text-blue-400 text-[9px] tracking-[0.25em] font-['Space_Mono']">EXPLORE · DISCOVER · LEARN</span>
            </div>
          </button>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNav(item.id)}
                className={`relative px-4 py-2 text-sm font-['Exo_2'] font-medium tracking-wider transition-all duration-300 rounded-md group ${
                  activeSection === item.id
                    ? "text-blue-400"
                    : "text-gray-300 hover:text-white"
                }`}
              >
                {activeSection === item.id && (
                  <motion.div
                    layoutId="nav-active"
                    className="absolute inset-0 bg-blue-900/40 rounded-md border border-blue-700/40"
                  />
                )}
                <span className="relative z-10">{item.label}</span>
              </button>
            ))}
            <div className="ml-4 px-4 py-1.5 rounded-full border border-blue-600/50 bg-blue-900/20 text-blue-300 text-xs font-['Space_Mono'] tracking-widest">
              BY ANSH MAURYA
            </div>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="md:hidden text-white p-2"
          >
            <div className="w-6 flex flex-col gap-1.5">
              <motion.span
                animate={menuOpen ? { rotate: 45, y: 8 } : { rotate: 0, y: 0 }}
                className="block h-0.5 bg-white rounded"
              />
              <motion.span
                animate={menuOpen ? { opacity: 0 } : { opacity: 1 }}
                className="block h-0.5 bg-white rounded"
              />
              <motion.span
                animate={menuOpen ? { rotate: -45, y: -8 } : { rotate: 0, y: 0 }}
                className="block h-0.5 bg-white rounded"
              />
            </div>
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-[#050d1a]/98 border-t border-blue-900/30"
          >
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNav(item.id)}
                className={`w-full text-left px-6 py-4 font-['Exo_2'] text-sm tracking-wider transition-colors ${
                  activeSection === item.id
                    ? "text-blue-400 bg-blue-900/30"
                    : "text-gray-300"
                }`}
              >
                {item.label}
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
}
