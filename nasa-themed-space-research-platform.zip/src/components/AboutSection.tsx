import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";

export default function AboutSection() {
  const [ref, inView] = useInView({ threshold: 0.1, triggerOnce: true });

  const timeline = [
    { year: "1957", event: "Sputnik 1 — First satellite in orbit (USSR)" },
    { year: "1961", event: "Yuri Gagarin — First human in space (USSR)" },
    { year: "1969", event: "Apollo 11 — First humans on the Moon (NASA)" },
    { year: "1977", event: "Voyager 1 & 2 launched for interstellar journey" },
    { year: "1990", event: "Hubble Space Telescope deployed" },
    { year: "1998", event: "ISS construction begins (International)" },
    { year: "2004", event: "Mars rovers Spirit & Opportunity land on Mars" },
    { year: "2006", event: "New Horizons launched toward Pluto" },
    { year: "2012", event: "Voyager 1 enters interstellar space" },
    { year: "2015", event: "Gravitational waves detected (LIGO)" },
    { year: "2019", event: "First black hole image captured (EHT)" },
    { year: "2021", event: "JWST launched; Perseverance lands on Mars" },
    { year: "2023", event: "Chandrayaan-3 lands at Moon's south pole (ISRO)" },
    { year: "2024+", event: "Artemis crewed Moon missions; Starship development" },
  ];

  return (
    <section id="about" className="relative py-24 bg-[#020812]">
      <div
        className="absolute inset-0 bg-cover bg-center opacity-10"
        style={{ backgroundImage: "url('/images/iss-space.jpg')" }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-[#020812] via-transparent to-[#020812]" />

      <div ref={ref} className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-green-500/30 bg-green-900/20 text-green-300 text-xs font-['Space_Mono'] tracking-widest mb-6">
            <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            ABOUT THIS PROJECT
          </div>
          <h2 className="font-['Orbitron'] font-bold text-4xl md:text-5xl text-white mb-4">
            Created by
            <span className="block bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent">
              Ansh Maurya
            </span>
          </h2>
          <p className="text-gray-400 font-['Exo_2'] max-w-2xl mx-auto text-lg">
            A passion-driven space exploration website built to educate, inspire, and celebrate
            humanity's greatest achievement — reaching beyond our home planet.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-20">
          {/* Creator Card */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.2 }}
          >
            <div className="bg-gradient-to-br from-blue-950/50 to-[#050d1a] border border-blue-700/40 rounded-3xl p-8">
              {/* Avatar */}
              <div className="flex items-center gap-5 mb-6">
                <div className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-500 to-blue-900 flex items-center justify-center shadow-xl shadow-blue-700/30 text-4xl">
                  🚀
                </div>
                <div>
                  <h3 className="font-['Orbitron'] text-2xl font-bold text-white">Ansh Maurya</h3>
                  <div className="text-blue-400 font-['Space_Mono'] text-sm">Space Enthusiast & Developer</div>
                  <div className="flex items-center gap-1 mt-1">
                    {[...Array(5)].map((_, i) => (
                      <span key={i} className="text-yellow-400 text-xs">★</span>
                    ))}
                  </div>
                </div>
              </div>

              <p className="text-gray-300 font-['Exo_2'] text-sm leading-relaxed mb-6">
                SpaceVerse is a comprehensive educational platform designed to make space science
                accessible to everyone. From exploring the first satellites to the latest Mars rovers,
                this portal is your gateway to humanity's cosmic journey — all presented in
                a NASA-inspired theme.
              </p>

              <div className="space-y-3">
                {[
                  { label: "Theme", val: "NASA Official Design Language" },
                  { label: "Mission", val: "Educate & Inspire Space Curiosity" },
                  { label: "Coverage", val: "All Major Space Agencies Worldwide" },
                  { label: "Data", val: "Historical + Active Missions (1957–2024+)" },
                ].map((item) => (
                  <div key={item.label} className="flex items-start gap-3">
                    <div className="w-1.5 h-1.5 rounded-full bg-blue-400 mt-2 flex-shrink-0" />
                    <div>
                      <span className="text-gray-500 font-['Exo_2'] text-xs">{item.label}: </span>
                      <span className="text-gray-200 font-['Exo_2'] text-xs">{item.val}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* NASA Theme Note */}
            <div className="mt-6 bg-[#0B3D91]/20 border border-[#0B3D91]/40 rounded-2xl p-5">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 rounded-full bg-[#0B3D91] flex items-center justify-center">
                  <span className="text-white text-xs font-bold font-['Orbitron']">N</span>
                </div>
                <h4 className="font-['Orbitron'] text-white text-sm font-bold">NASA Theme</h4>
              </div>
              <p className="text-gray-400 font-['Exo_2'] text-xs leading-relaxed">
                This website follows NASA's official design principles — using deep navy blues (#0B3D91),
                space black backgrounds, Orbitron/Exo 2 typefaces for that authentic aerospace aesthetic.
                The color palette, typography, and visual language are inspired by NASA's brand guidelines.
              </p>
              <div className="flex gap-2 mt-3">
                {["#0B3D91", "#3B82F6", "#06B6D4", "#020812", "#FFFFFF"].map((c) => (
                  <div
                    key={c}
                    className="w-6 h-6 rounded-full border border-white/10 cursor-default"
                    style={{ backgroundColor: c }}
                    title={c}
                  />
                ))}
              </div>
            </div>
          </motion.div>

          {/* Space History Timeline */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.3 }}
          >
            <h3 className="font-['Orbitron'] text-white text-xl font-bold mb-6 text-center">
              Space History Timeline
            </h3>
            <div className="relative">
              {/* Timeline line */}
              <div className="absolute left-14 top-0 bottom-0 w-px bg-blue-800/40" />

              <div className="space-y-4 max-h-[520px] overflow-y-auto pr-2 custom-scroll">
                {timeline.map((item, i) => (
                  <motion.div
                    key={item.year}
                    initial={{ opacity: 0, x: 20 }}
                    animate={inView ? { opacity: 1, x: 0 } : {}}
                    transition={{ delay: 0.05 * i + 0.3 }}
                    className="flex items-start gap-4 relative pl-14"
                  >
                    <div className="absolute left-11 top-2 w-3 h-3 rounded-full bg-blue-600 border-2 border-blue-400 shadow-sm shadow-blue-400/50" />
                    <div className="absolute left-0 text-blue-400 font-['Space_Mono'] text-xs font-bold w-10 text-right pt-1">
                      {item.year}
                    </div>
                    <div className="bg-blue-950/30 border border-blue-800/30 rounded-xl px-4 py-2.5 flex-1 hover:border-blue-600/50 transition-colors">
                      <p className="text-gray-300 font-['Exo_2'] text-xs leading-relaxed">{item.event}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>

        {/* ISS Image strip */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.4 }}
          className="rounded-3xl overflow-hidden"
        >
          <div
            className="relative h-60 bg-cover bg-center"
            style={{ backgroundImage: "url('/images/iss-space.jpg')" }}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-[#020812]/90 via-[#020812]/60 to-[#020812]/40" />
            <div className="absolute inset-0 flex items-center px-10">
              <div>
                <h3 className="font-['Orbitron'] text-3xl font-bold text-white mb-3">
                  Together We Reach the Stars
                </h3>
                <p className="text-gray-300 font-['Exo_2'] max-w-lg text-sm leading-relaxed">
                  Space exploration is humanity's greatest collaborative achievement — uniting
                  nations, inspiring generations, and expanding our understanding of the cosmos.
                  This is just the beginning.
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
