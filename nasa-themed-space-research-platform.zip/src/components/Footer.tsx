

export default function Footer() {
  const links = {
    Explore: ["Space Research", "Spacecraft", "Research Dictionary", "About"],
    Agencies: ["NASA", "ESA", "Roscosmos", "ISRO", "JAXA", "CNSA", "SpaceX"],
    Topics: ["Cosmology", "Astrophysics", "Planetary Science", "Exoplanets", "Earth Science"],
  };

  const handleNav = (id: string) => {
    const map: Record<string, string> = {
      "Space Research": "research",
      Spacecraft: "spacecraft",
      "Research Dictionary": "dictionary",
      About: "about",
    };
    const targetId = map[id] || "home";
    const el = document.getElementById(targetId);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <footer className="bg-[#020812] border-t border-blue-900/30 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div className="md:col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-blue-900 flex items-center justify-center">
                <svg viewBox="0 0 24 24" className="w-6 h-6 fill-white">
                  <circle cx="12" cy="12" r="4" />
                  <path d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm0 18c-4.411 0-8-3.589-8-8s3.589-8 8-8 8 3.589 8 8-3.589 8-8 8z" />
                </svg>
              </div>
              <span className="font-['Orbitron'] text-white font-bold tracking-widest">SPACEVERSE</span>
            </div>
            <p className="text-gray-500 font-['Exo_2'] text-sm leading-relaxed mb-4">
              Your comprehensive NASA-themed portal for space research, spacecraft history,
              and cosmic discovery — built with passion by Ansh Maurya.
            </p>
            <div className="text-xs font-['Space_Mono'] text-blue-500">
              CREATED BY ANSH MAURYA
            </div>
          </div>

          {/* Links */}
          {Object.entries(links).map(([category, items]) => (
            <div key={category}>
              <h4 className="font-['Orbitron'] text-white text-sm font-bold tracking-wider mb-4">
                {category}
              </h4>
              <ul className="space-y-2">
                {items.map((item) => (
                  <li key={item}>
                    <button
                      onClick={() => handleNav(item)}
                      className="text-gray-500 font-['Exo_2'] text-sm hover:text-blue-400 transition-colors text-left"
                    >
                      {item}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Color palette display */}
        <div className="flex items-center gap-3 mb-8">
          <span className="text-gray-600 font-['Space_Mono'] text-xs">NASA PALETTE</span>
          {[
            { c: "#0B3D91", n: "NASA Blue" },
            { c: "#3B82F6", n: "Sky Blue" },
            { c: "#06B6D4", n: "Cyan" },
            { c: "#FC3D21", n: "NASA Red" },
            { c: "#FFFFFF", n: "White" },
          ].map((p) => (
            <div key={p.c} className="group relative">
              <div
                className="w-5 h-5 rounded-full border border-white/10"
                style={{ backgroundColor: p.c }}
              />
              <div className="absolute bottom-7 left-1/2 -translate-x-1/2 hidden group-hover:block bg-black text-white text-[10px] px-2 py-1 rounded font-['Space_Mono'] whitespace-nowrap">
                {p.n}
              </div>
            </div>
          ))}
        </div>

        {/* Bottom */}
        <div className="border-t border-blue-900/30 pt-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-gray-600 font-['Exo_2'] text-xs">
            © 2024 SpaceVerse. Created by{" "}
            <span className="text-blue-400 font-bold">Ansh Maurya</span>. All rights reserved.
          </div>
          <div className="flex items-center gap-2 text-gray-700 font-['Space_Mono'] text-xs">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            ALL SYSTEMS NOMINAL · MISSION ACTIVE
          </div>
          <div className="text-gray-700 font-['Space_Mono'] text-xs">
            THEMED AFTER NASA DESIGN SYSTEM
          </div>
        </div>
      </div>
    </footer>
  );
}
