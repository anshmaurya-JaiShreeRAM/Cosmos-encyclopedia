import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";

interface HeroSectionProps {
  setActiveSection: (s: string) => void;
}

export default function HeroSection({ setActiveSection }: HeroSectionProps) {
  const [ref, inView] = useInView({ threshold: 0.1, triggerOnce: true });

  const handleNav = (id: string) => {
    setActiveSection(id);
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: "url('/images/hero-space.jpg')" }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-[#020812]/70 via-[#020812]/50 to-[#020812]" />

      {/* Animated Orbit rings */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        {[200, 300, 420, 560].map((size, i) => (
          <motion.div
            key={size}
            className="absolute rounded-full border border-blue-700/20"
            style={{ width: size, height: size }}
            animate={{ rotate: 360 }}
            transition={{ duration: 20 + i * 8, repeat: Infinity, ease: "linear" }}
          />
        ))}
        {/* Orbiting dot */}
        <motion.div
          className="absolute w-3 h-3 rounded-full bg-blue-400 shadow-lg shadow-blue-400/80"
          style={{ top: "calc(50% - 150px)", left: "50%" }}
          animate={{ rotate: 360 }}
          transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
        />
      </div>

      <div ref={ref} className="relative z-10 text-center max-w-5xl mx-auto px-4">
        {/* Badge */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.2 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-blue-500/40 bg-blue-900/20 backdrop-blur-sm text-blue-300 text-xs font-['Space_Mono'] tracking-widest mb-8"
        >
          <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
          NASA-THEMED SPACE EXPLORATION PORTAL
        </motion.div>

        {/* Main heading */}
        <motion.h1
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.3 }}
          className="font-['Orbitron'] font-black text-5xl md:text-7xl lg:text-8xl text-white leading-tight mb-6"
        >
          <span className="block">EXPLORE</span>
          <span className="block bg-gradient-to-r from-blue-400 via-cyan-300 to-blue-600 bg-clip-text text-transparent">
            THE COSMOS
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.4 }}
          className="text-gray-300 text-lg md:text-xl font-['Exo_2'] max-w-3xl mx-auto mb-10 leading-relaxed"
        >
          Your comprehensive guide to space research, every spacecraft ever built, and
          the complete dictionary of humanity's greatest cosmic discoveries — all in one
          NASA-inspired portal.
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.5 }}
          className="flex flex-wrap gap-4 justify-center mb-16"
        >
          <button
            onClick={() => handleNav("spacecraft")}
            className="px-8 py-4 rounded-lg bg-gradient-to-r from-blue-600 to-blue-800 text-white font-['Orbitron'] text-sm tracking-widest hover:from-blue-500 hover:to-blue-700 transition-all duration-300 shadow-lg shadow-blue-900/50 hover:shadow-blue-700/50 hover:scale-105"
          >
            EXPLORE SPACECRAFT
          </button>
          <button
            onClick={() => handleNav("research")}
            className="px-8 py-4 rounded-lg border border-blue-500/50 text-blue-300 font-['Orbitron'] text-sm tracking-widest hover:bg-blue-900/30 hover:border-blue-400 transition-all duration-300 hover:scale-105"
          >
            VIEW RESEARCH
          </button>
        </motion.div>

        {/* Stats row */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.6 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto"
        >
          {[
            { number: "20+", label: "Spacecraft Profiled" },
            { number: "18+", label: "Research Studies" },
            { number: "7", label: "Space Agencies" },
            { number: "65+", label: "Years of History" },
          ].map((stat) => (
            <div
              key={stat.label}
              className="bg-white/5 backdrop-blur-sm border border-blue-800/30 rounded-xl p-4"
            >
              <div className="font-['Orbitron'] text-2xl font-bold text-blue-300 mb-1">
                {stat.number}
              </div>
              <div className="text-gray-400 text-xs font-['Exo_2'] tracking-wider">
                {stat.label}
              </div>
            </div>
          ))}
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-blue-400/60 flex flex-col items-center gap-1"
      >
        <span className="text-xs font-['Space_Mono'] tracking-widest">SCROLL</span>
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </motion.div>
    </section>
  );
}
