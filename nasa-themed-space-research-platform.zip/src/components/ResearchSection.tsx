import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";

export default function ResearchSection() {
  const [ref, inView] = useInView({ threshold: 0.05, triggerOnce: true });

  const areas = [
    {
      icon: "🚀",
      title: "Propulsion Technology",
      desc: "From chemical rockets to ion drives and nuclear propulsion — pushing the boundaries of how we travel through space.",
      programs: ["SLS", "Raptor Engine", "ion propulsion", "Nuclear Thermal"],
    },
    {
      icon: "🛸",
      title: "Deep Space Exploration",
      desc: "Missions beyond our solar system and to the outer planets of our cosmic neighborhood, studying interstellar medium.",
      programs: ["Voyager Program", "New Horizons", "Parker Solar Probe", "IMAP"],
    },
    {
      icon: "🔭",
      title: "Astronomical Observation",
      desc: "Space-based telescopes revealing the universe from infrared to X-ray, looking back to the dawn of time itself.",
      programs: ["James Webb ST", "Chandra X-Ray", "Spitzer", "Roman ST"],
    },
    {
      icon: "🪐",
      title: "Planetary Science",
      desc: "Studying planets, moons, asteroids, and comets to understand how our solar system formed and evolved.",
      programs: ["Cassini", "Juno", "OSIRIS-REx", "Lucy Mission"],
    },
    {
      icon: "🧬",
      title: "Astrobiology",
      desc: "Searching for signs of life — past or present — beyond Earth, in the oceans of Europa and the sands of Mars.",
      programs: ["Mars Life Explorer", "Europa Clipper", "LIFE Mission"],
    },
    {
      icon: "🌍",
      title: "Earth Observation",
      desc: "Monitoring our home planet's climate, weather, and environment from orbit to address global challenges.",
      programs: ["GRACE-FO", "Landsat 9", "ICESat-2", "TEMPO"],
    },
    {
      icon: "👨‍🚀",
      title: "Human Spaceflight",
      desc: "Advancing technologies to send humans to the Moon, Mars, and beyond — keeping explorers safe and productive.",
      programs: ["Artemis Program", "Gateway Station", "xEMU Suit", "CHAPEA"],
    },
    {
      icon: "⚛️",
      title: "Space Physics & Heliophysics",
      desc: "Understanding the Sun, solar wind, magnetospheres, and their effects on Earth and deep space travelers.",
      programs: ["MMS Mission", "ACE", "WIND", "Solar Orbiter"],
    },
  ];

  const agencies = [
    { name: "NASA", country: "🇺🇸 USA", founded: 1958, budget: "$24.8B", missions: "500+", color: "#0B3D91" },
    { name: "ESA", country: "🇪🇺 Europe", founded: 1975, budget: "€7.8B", missions: "90+", color: "#003299" },
    { name: "Roscosmos", country: "🇷🇺 Russia", founded: 1992, budget: "$2.7B", missions: "1800+", color: "#1F4B8E" },
    { name: "ISRO", country: "🇮🇳 India", founded: 1969, budget: "$1.9B", missions: "100+", color: "#FF8C00" },
    { name: "JAXA", country: "🇯🇵 Japan", founded: 2003, budget: "$2.1B", missions: "50+", color: "#1B4F9B" },
    { name: "CNSA", country: "🇨🇳 China", founded: 1993, budget: "$12B", missions: "200+", color: "#DE2910" },
    { name: "SpaceX", country: "🚀 USA (Pvt)", founded: 2002, budget: "Private", missions: "250+", color: "#2F4F4F" },
    { name: "Blue Origin", country: "🚀 USA (Pvt)", founded: 2000, budget: "Private", missions: "40+", color: "#1565c0" },
  ];

  return (
    <section id="research" className="relative py-24 bg-[#020812]">
      <div
        className="absolute inset-0 bg-cover bg-center opacity-10"
        style={{ backgroundImage: "url('/images/research-banner.jpg')" }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-[#020812] via-transparent to-[#020812]" />

      <div ref={ref} className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-blue-500/30 bg-blue-900/20 text-blue-300 text-xs font-['Space_Mono'] tracking-widest mb-6">
            <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
            SPACE RESEARCH & DEVELOPMENT
          </div>
          <h2 className="font-['Orbitron'] font-bold text-4xl md:text-5xl text-white mb-4">
            Humanity's Quest
            <span className="block text-blue-400">Beyond Earth</span>
          </h2>
          <p className="text-gray-400 font-['Exo_2'] max-w-2xl mx-auto text-lg">
            Explore the eight pillars of space research and development driving humanity's
            greatest adventure — from propulsion to life detection.
          </p>
        </motion.div>

        {/* Research areas grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-24">
          {areas.map((area, i) => (
            <motion.div
              key={area.title}
              initial={{ opacity: 0, y: 40 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: i * 0.08, duration: 0.6 }}
              className="group bg-gradient-to-br from-blue-950/40 to-[#050d1a]/80 border border-blue-800/30 rounded-2xl p-6 hover:border-blue-500/50 hover:bg-blue-900/20 transition-all duration-400 cursor-default"
            >
              <div className="text-4xl mb-4">{area.icon}</div>
              <h3 className="font-['Orbitron'] font-bold text-white text-sm mb-3 group-hover:text-blue-300 transition-colors">
                {area.title}
              </h3>
              <p className="text-gray-400 text-xs font-['Exo_2'] leading-relaxed mb-4">
                {area.desc}
              </p>
              <div className="flex flex-wrap gap-1">
                {area.programs.map((p) => (
                  <span
                    key={p}
                    className="text-[10px] font-['Space_Mono'] px-2 py-0.5 rounded-full bg-blue-900/40 border border-blue-700/30 text-blue-400"
                  >
                    {p}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Featured Mission */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.5 }}
          className="mb-24 rounded-3xl overflow-hidden border border-blue-700/30"
        >
          <div
            className="relative h-72 bg-cover bg-center"
            style={{ backgroundImage: "url('/images/mars-rover.jpg')" }}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-[#020812]/90 via-[#020812]/60 to-transparent" />
            <div className="absolute inset-0 flex items-center px-10">
              <div className="max-w-xl">
                <span className="inline-block px-3 py-1 rounded-full bg-red-700/60 border border-red-500/40 text-red-300 text-xs font-['Space_Mono'] tracking-widest mb-4">
                  ACTIVE MISSION
                </span>
                <h3 className="font-['Orbitron'] text-3xl font-bold text-white mb-3">
                  Perseverance Rover
                </h3>
                <p className="text-gray-300 font-['Exo_2'] text-sm leading-relaxed mb-4">
                  NASA's most advanced Mars rover is currently collecting rock samples in
                  Jezero Crater, searching for signs of ancient microbial life and caching
                  specimens for future return to Earth.
                </p>
                <div className="flex gap-6 text-sm">
                  <div>
                    <div className="text-blue-400 font-['Orbitron'] font-bold">Feb 2021</div>
                    <div className="text-gray-500 font-['Exo_2'] text-xs">Landing Date</div>
                  </div>
                  <div>
                    <div className="text-green-400 font-['Orbitron'] font-bold">Active</div>
                    <div className="text-gray-500 font-['Exo_2'] text-xs">Mission Status</div>
                  </div>
                  <div>
                    <div className="text-yellow-400 font-['Orbitron'] font-bold">50+</div>
                    <div className="text-gray-500 font-['Exo_2'] text-xs">Rock Samples</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Space Agencies */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.3 }}
        >
          <h3 className="font-['Orbitron'] font-bold text-2xl text-white text-center mb-10">
            World's Space Agencies
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {agencies.map((agency, i) => (
              <motion.div
                key={agency.name}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={inView ? { opacity: 1, scale: 1 } : {}}
                transition={{ delay: 0.1 * i }}
                className="bg-[#050d1a]/80 border border-blue-800/30 rounded-xl p-5 text-center hover:border-blue-500/50 transition-all duration-300 hover:-translate-y-1"
              >
                <div
                  className="w-10 h-10 rounded-full mx-auto mb-3 flex items-center justify-center font-['Orbitron'] text-white text-xs font-bold"
                  style={{ backgroundColor: agency.color }}
                >
                  {agency.name.slice(0, 2)}
                </div>
                <div className="font-['Orbitron'] text-white font-bold text-sm mb-1">{agency.name}</div>
                <div className="text-gray-400 font-['Exo_2'] text-xs mb-3">{agency.country}</div>
                <div className="space-y-1 text-left">
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-500 font-['Exo_2']">Founded</span>
                    <span className="text-blue-300 font-['Space_Mono']">{agency.founded}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-500 font-['Exo_2']">Budget</span>
                    <span className="text-green-300 font-['Space_Mono'] text-[10px]">{agency.budget}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-500 font-['Exo_2']">Missions</span>
                    <span className="text-yellow-300 font-['Space_Mono']">{agency.missions}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
