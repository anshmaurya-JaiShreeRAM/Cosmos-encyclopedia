import { motion } from "framer-motion";

const planets = [
  { name: "Mercury", color: "#b5b5b5", size: 8, orbit: 80, duration: 4, angle: 30 },
  { name: "Venus", color: "#e8cda0", size: 12, orbit: 120, duration: 7, angle: 100 },
  { name: "Earth", color: "#4a90d9", size: 13, orbit: 165, duration: 10, angle: 200, hasMoon: true },
  { name: "Mars", color: "#c1440e", size: 10, orbit: 210, duration: 15, angle: 310 },
  { name: "Jupiter", color: "#c88b3a", size: 24, orbit: 275, duration: 25, angle: 60 },
  { name: "Saturn", color: "#e4d191", size: 20, orbit: 335, duration: 35, angle: 150, hasRing: true },
];

export default function SolarSystemViz() {
  return (
    <section className="relative py-16 bg-[#020812] overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 text-center mb-10">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-yellow-500/30 bg-yellow-900/20 text-yellow-300 text-xs font-['Space_Mono'] tracking-widest mb-4">
          <span className="w-2 h-2 rounded-full bg-yellow-400 animate-pulse" />
          INTERACTIVE SOLAR SYSTEM
        </div>
        <h2 className="font-['Orbitron'] font-bold text-3xl text-white">
          Our Solar System
        </h2>
      </div>

      <div className="relative flex items-center justify-center" style={{ height: 720 }}>
        {/* Sun */}
        <div className="absolute z-20">
          <motion.div
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 3, repeat: Infinity }}
            className="w-16 h-16 rounded-full"
            style={{
              background: "radial-gradient(circle at 35% 35%, #fff7c0, #ffd700, #ff8c00, #ff4500)",
              boxShadow: "0 0 40px #ffd700, 0 0 80px #ff8c0060, 0 0 120px #ff450030",
            }}
          />
        </div>

        {/* Orbits and planets */}
        {planets.map((planet) => (
          <div key={planet.name} className="absolute" style={{ width: planet.orbit * 2, height: planet.orbit * 2 }}>
            {/* Orbit ring */}
            <div
              className="absolute inset-0 rounded-full border border-blue-900/30"
            />

            {/* Planet */}
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: planet.duration, repeat: Infinity, ease: "linear" }}
              className="absolute inset-0"
              style={{ transformOrigin: "center" }}
            >
              <div
                className="absolute"
                style={{
                  top: 0,
                  left: "50%",
                  transform: "translateX(-50%)",
                  marginTop: -planet.size / 2,
                }}
              >
                {/* Saturn ring */}
                {planet.hasRing && (
                  <div
                    className="absolute"
                    style={{
                      width: planet.size * 2.5,
                      height: planet.size * 0.4,
                      border: "2px solid #c8a84b80",
                      borderRadius: "50%",
                      top: "50%",
                      left: "50%",
                      transform: "translate(-50%, -50%)",
                    }}
                  />
                )}

                <div
                  className="rounded-full relative"
                  style={{
                    width: planet.size,
                    height: planet.size,
                    background: planet.hasRing
                      ? `radial-gradient(circle at 35% 35%, #f5e6a3, ${planet.color}, #a8882a)`
                      : planet.name === "Earth"
                      ? "radial-gradient(circle at 35% 35%, #7cc8f2, #4a90d9, #2a6a9e)"
                      : planet.name === "Mars"
                      ? "radial-gradient(circle at 35% 35%, #e05c2a, #c1440e, #8b2800)"
                      : planet.name === "Jupiter"
                      ? "radial-gradient(circle at 35% 35%, #e8c87a, #c88b3a, #8b6020)"
                      : `radial-gradient(circle at 35% 35%, white, ${planet.color})`,
                    boxShadow: `0 0 8px ${planet.color}60`,
                  }}
                />

                {/* Earth Moon */}
                {planet.hasMoon && (
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                    className="absolute"
                    style={{
                      width: planet.size * 2.5,
                      height: planet.size * 2.5,
                      top: "50%",
                      left: "50%",
                      transform: "translate(-50%, -50%)",
                    }}
                  >
                    <div
                      className="absolute rounded-full"
                      style={{
                        width: 5,
                        height: 5,
                        background: "#d0d0d0",
                        top: 0,
                        left: "50%",
                        transform: "translateX(-50%)",
                        boxShadow: "0 0 4px #d0d0d0",
                      }}
                    />
                  </motion.div>
                )}

                {/* Planet label */}
                <div
                  className="absolute font-['Space_Mono'] text-gray-400 whitespace-nowrap"
                  style={{
                    fontSize: 9,
                    top: planet.size + 4,
                    left: "50%",
                    transform: "translateX(-50%)",
                  }}
                >
                  {planet.name}
                </div>
              </div>
            </motion.div>
          </div>
        ))}

        {/* Asteroid belt */}
        <div className="absolute" style={{ width: 480, height: 480 }}>
          <div className="absolute inset-0 rounded-full border border-dotted border-gray-700/20" />
          {[...Array(30)].map((_, i) => {
            const angle = (i / 30) * 360;
            const r = 237 + (Math.random() * 8 - 4);
            const x = 240 + r * Math.cos((angle * Math.PI) / 180);
            const y = 240 + r * Math.sin((angle * Math.PI) / 180);
            return (
              <div
                key={i}
                className="absolute rounded-full bg-gray-600/60"
                style={{
                  width: Math.random() * 2 + 1,
                  height: Math.random() * 2 + 1,
                  left: x,
                  top: y,
                }}
              />
            );
          })}
        </div>
      </div>

      {/* Planet info strip */}
      <div className="max-w-7xl mx-auto px-4 mt-4">
        <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
          {planets.map((p) => (
            <div
              key={p.name}
              className="bg-blue-950/20 border border-blue-900/30 rounded-xl p-3 text-center"
            >
              <div
                className="w-6 h-6 rounded-full mx-auto mb-2"
                style={{ backgroundColor: p.color }}
              />
              <div className="font-['Space_Mono'] text-white text-xs">{p.name}</div>
              <div className="text-gray-500 text-[10px] font-['Exo_2']">
                {p.duration}yr orbit
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
