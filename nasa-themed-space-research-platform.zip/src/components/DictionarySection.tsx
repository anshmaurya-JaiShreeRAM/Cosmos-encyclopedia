import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useInView } from "react-intersection-observer";
import { researchDictionary, researchCategories, ResearchEntry } from "../data/researchData";

export default function DictionarySection() {
  const [ref, inView] = useInView({ threshold: 0.05, triggerOnce: true });
  const [category, setCategory] = useState("All");
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<ResearchEntry | null>(null);

  const filtered = researchDictionary.filter((r) => {
    const matchCat = category === "All" || r.category === category;
    const matchSearch =
      search === "" ||
      r.title.toLowerCase().includes(search.toLowerCase()) ||
      r.agency.toLowerCase().includes(search.toLowerCase()) ||
      r.tags.some((t) => t.toLowerCase().includes(search.toLowerCase())) ||
      r.description.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  const categoryColors: Record<string, string> = {
    Cosmology: "#6366f1",
    Astrophysics: "#8b5cf6",
    "Planetary Science": "#f59e0b",
    Exoplanets: "#10b981",
    "Solar Physics": "#f97316",
    "Lunar Science": "#94a3b8",
    "Earth Science": "#22c55e",
    "Interstellar Science": "#3b82f6",
    "Particle Physics": "#ec4899",
  };

  return (
    <section id="dictionary" className="relative py-24 bg-[#020812]">
      <div
        className="absolute inset-0 bg-cover bg-center opacity-10"
        style={{ backgroundImage: "url('/images/galaxy-bg.jpg')" }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-[#020812] via-transparent to-[#020812]" />

      <div ref={ref} className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-purple-500/30 bg-purple-900/20 text-purple-300 text-xs font-['Space_Mono'] tracking-widest mb-6">
            <span className="w-2 h-2 rounded-full bg-purple-400 animate-pulse" />
            SPACE RESEARCH DICTIONARY
          </div>
          <h2 className="font-['Orbitron'] font-bold text-4xl md:text-5xl text-white mb-4">
            Global Space
            <span className="block text-purple-400">Research Archive</span>
          </h2>
          <p className="text-gray-400 font-['Exo_2'] max-w-2xl mx-auto">
            The most comprehensive dictionary of space research ever compiled —
            spanning cosmology, astrophysics, planetary science, and beyond.
            From the Big Bang to black holes, all discoveries catalogued here.
          </p>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-3 gap-4 max-w-lg mx-auto mb-10"
        >
          {[
            { n: researchDictionary.length + "+", l: "Research Studies" },
            { n: "10", l: "Scientific Fields" },
            { n: "60+", l: "Years Covered" },
          ].map((s) => (
            <div key={s.l} className="text-center bg-purple-900/10 border border-purple-700/20 rounded-xl py-4">
              <div className="font-['Orbitron'] text-xl font-bold text-purple-300">{s.n}</div>
              <div className="text-gray-500 text-xs font-['Exo_2']">{s.l}</div>
            </div>
          ))}
        </motion.div>

        {/* Search */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.25 }}
          className="relative max-w-lg mx-auto mb-6"
        >
          <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search discoveries, agencies, tags..."
            className="w-full bg-purple-950/30 border border-purple-700/30 rounded-xl pl-10 pr-4 py-3 text-white font-['Exo_2'] text-sm focus:outline-none focus:border-purple-500 placeholder-gray-500"
          />
        </motion.div>

        {/* Category Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.3 }}
          className="flex flex-wrap gap-2 justify-center mb-8"
        >
          {researchCategories.map((cat) => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={`px-3 py-1.5 rounded-full text-xs font-['Exo_2'] font-medium tracking-wider transition-all duration-200 ${
                category === cat
                  ? "bg-purple-600 text-white shadow-lg shadow-purple-700/40"
                  : "bg-purple-950/30 border border-purple-700/30 text-gray-400 hover:border-purple-500 hover:text-white"
              }`}
            >
              {cat}
            </button>
          ))}
        </motion.div>

        <div className="text-center text-gray-500 text-xs font-['Space_Mono'] mb-8">
          {filtered.length} ENTRIES FOUND
        </div>

        {/* Research Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          <AnimatePresence mode="popLayout">
            {filtered.map((entry, i) => {
              const color = categoryColors[entry.category] || "#6366f1";
              return (
                <motion.div
                  key={entry.id}
                  layout
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ delay: i * 0.05 }}
                  onClick={() => setSelected(entry)}
                  className="group cursor-pointer bg-gradient-to-br from-[#0a0f20] to-[#020812] border border-purple-900/30 rounded-2xl p-5 hover:border-purple-500/50 transition-all duration-400 hover:-translate-y-1 hover:shadow-xl hover:shadow-purple-900/20"
                >
                  {/* Top row */}
                  <div className="flex items-start justify-between mb-3">
                    <div
                      className="text-xs font-['Space_Mono'] px-2 py-0.5 rounded-full border"
                      style={{
                        backgroundColor: `${color}20`,
                        borderColor: `${color}40`,
                        color: color,
                      }}
                    >
                      {entry.category}
                    </div>
                    <span className="text-gray-600 text-xs font-['Space_Mono']">{entry.year}</span>
                  </div>

                  {/* Title */}
                  <h3 className="font-['Orbitron'] text-white text-sm font-bold mb-2 group-hover:text-purple-300 transition-colors leading-snug">
                    {entry.title}
                  </h3>

                  {/* Agency */}
                  <div className="text-purple-400 text-xs font-['Space_Mono'] mb-3">{entry.agency}</div>

                  {/* Description */}
                  <p className="text-gray-400 text-xs font-['Exo_2'] leading-relaxed mb-4 line-clamp-3">
                    {entry.description}
                  </p>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-1 mb-3">
                    {entry.tags.slice(0, 4).map((tag) => (
                      <span
                        key={tag}
                        className="text-[10px] font-['Space_Mono'] px-2 py-0.5 rounded-full bg-blue-900/30 border border-blue-800/30 text-blue-400"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  {/* Significance */}
                  <div className="border-t border-purple-900/30 pt-3 mt-auto">
                    <div className="text-[10px] text-gray-600 font-['Exo_2'] uppercase tracking-wider mb-1">Significance</div>
                    <div className="text-gray-300 text-xs font-['Exo_2'] line-clamp-2">{entry.significance}</div>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-20 text-gray-500 font-['Exo_2']">
            No research entries found. Try a different search term.
          </div>
        )}
      </div>

      {/* Detail Modal */}
      <AnimatePresence>
        {selected && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md"
            onClick={() => setSelected(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 40 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-2xl max-h-[85vh] overflow-y-auto bg-[#080f20] border border-purple-700/40 rounded-3xl"
            >
              {/* Modal Header */}
              <div className="relative p-6 border-b border-purple-800/30">
                <button
                  onClick={() => setSelected(null)}
                  className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white text-sm flex items-center justify-center"
                >
                  ✕
                </button>
                <div className="mb-3">
                  <span
                    className="text-xs font-['Space_Mono'] px-3 py-1 rounded-full border"
                    style={{
                      backgroundColor: `${categoryColors[selected.category] || "#6366f1"}20`,
                      borderColor: `${categoryColors[selected.category] || "#6366f1"}40`,
                      color: categoryColors[selected.category] || "#6366f1",
                    }}
                  >
                    {selected.category}
                  </span>
                </div>
                <h2 className="font-['Orbitron'] text-white text-xl font-bold mb-2">{selected.title}</h2>
                <div className="flex items-center gap-4 text-sm">
                  <span className="text-purple-400 font-['Space_Mono']">{selected.agency}</span>
                  <span className="text-gray-500 font-['Space_Mono']">{selected.year}</span>
                </div>
              </div>

              <div className="p-6 space-y-5">
                <div>
                  <h3 className="font-['Orbitron'] text-purple-300 text-xs font-bold mb-2">OVERVIEW</h3>
                  <p className="text-gray-300 font-['Exo_2'] text-sm leading-relaxed">{selected.description}</p>
                </div>

                <div className="bg-purple-900/15 border border-purple-700/25 rounded-xl p-4">
                  <h3 className="font-['Orbitron'] text-purple-300 text-xs font-bold mb-2">SCIENTIFIC SIGNIFICANCE</h3>
                  <p className="text-white font-['Exo_2'] text-sm">{selected.significance}</p>
                </div>

                <div>
                  <h3 className="font-['Orbitron'] text-purple-300 text-xs font-bold mb-3">KEY FINDINGS</h3>
                  <ul className="space-y-2">
                    {selected.keyFindings.map((f, i) => (
                      <li key={i} className="flex items-start gap-3 text-gray-300 font-['Exo_2'] text-sm">
                        <span className="w-5 h-5 rounded-full bg-purple-800/50 flex items-center justify-center text-purple-300 text-xs flex-shrink-0 mt-0.5">{i + 1}</span>
                        {f}
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h3 className="font-['Orbitron'] text-purple-300 text-xs font-bold mb-3">TAGS</h3>
                  <div className="flex flex-wrap gap-2">
                    {selected.tags.map((tag) => (
                      <span key={tag} className="text-xs font-['Space_Mono'] px-3 py-1 rounded-full bg-blue-900/30 border border-blue-800/30 text-blue-400">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
