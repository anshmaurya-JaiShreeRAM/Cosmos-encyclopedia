import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useInView } from "react-intersection-observer";
import { spacecraftData, Spacecraft } from "../data/spacecraftData";
import SpacecraftModel3D from "./SpacecraftModel3D";

const categories = ["All", "crewed", "probe", "telescope", "robotic", "satellite", "station", "lander"];
const agencyFilter = ["All", "NASA", "ESA", "Roscosmos", "ISRO", "JAXA", "CNSA", "SpaceX", "Soviet Space Program"];

export default function SpacecraftSection() {
  const [ref, inView] = useInView({ threshold: 0.05, triggerOnce: true });
  const [selected, setSelected] = useState<Spacecraft | null>(null);
  const [catFilter, setCatFilter] = useState("All");
  const [agencyF, setAgencyF] = useState("All");
  const [search, setSearch] = useState("");

  const filtered = spacecraftData.filter((s) => {
    const matchCat = catFilter === "All" || s.category === catFilter;
    const matchAgency = agencyF === "All" || s.agency.includes(agencyF);
    const matchSearch =
      search === "" ||
      s.name.toLowerCase().includes(search.toLowerCase()) ||
      s.agency.toLowerCase().includes(search.toLowerCase()) ||
      s.mission.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchAgency && matchSearch;
  });

  return (
    <section id="spacecraft" className="relative py-24 bg-[#020812]">
      <div
        className="absolute inset-0 bg-cover bg-center opacity-8"
        style={{ backgroundImage: "url('/images/spacecraft-banner.jpg')" }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-[#020812] via-[#020812]/95 to-[#020812]" />

      <div ref={ref} className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-cyan-500/30 bg-cyan-900/20 text-cyan-300 text-xs font-['Space_Mono'] tracking-widest mb-6">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
            SPACECRAFT ENCYCLOPEDIA
          </div>
          <h2 className="font-['Orbitron'] font-bold text-4xl md:text-5xl text-white mb-4">
            Every Spacecraft
            <span className="block text-cyan-400">Ever Built</span>
          </h2>
          <p className="text-gray-400 font-['Exo_2'] max-w-2xl mx-auto">
            A comprehensive catalog of spacecraft from all major space agencies — with interactive 3D models,
            detailed specifications, and mission highlights.
          </p>
        </motion.div>

        {/* Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.2 }}
          className="mb-8 space-y-4"
        >
          {/* Search */}
          <div className="relative max-w-md mx-auto">
            <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search spacecraft, agency, or mission..."
              className="w-full bg-blue-950/40 border border-blue-700/30 rounded-xl pl-10 pr-4 py-3 text-white font-['Exo_2'] text-sm focus:outline-none focus:border-blue-500 placeholder-gray-500"
            />
          </div>

          {/* Category filter */}
          <div className="flex flex-wrap gap-2 justify-center">
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => setCatFilter(c)}
                className={`px-3 py-1.5 rounded-full text-xs font-['Exo_2'] font-medium tracking-wider transition-all duration-200 capitalize ${
                  catFilter === c
                    ? "bg-blue-600 text-white shadow-lg shadow-blue-700/40"
                    : "bg-blue-950/40 border border-blue-700/30 text-gray-400 hover:border-blue-500 hover:text-white"
                }`}
              >
                {c}
              </button>
            ))}
          </div>

          {/* Agency filter */}
          <div className="flex flex-wrap gap-2 justify-center">
            {agencyFilter.map((a) => (
              <button
                key={a}
                onClick={() => setAgencyF(a)}
                className={`px-3 py-1.5 rounded-full text-xs font-['Space_Mono'] tracking-wider transition-all duration-200 ${
                  agencyF === a
                    ? "bg-cyan-700 text-white shadow-lg shadow-cyan-800/40"
                    : "bg-blue-950/40 border border-blue-700/30 text-gray-400 hover:border-cyan-500 hover:text-white"
                }`}
              >
                {a}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Count */}
        <div className="text-center text-gray-500 text-xs font-['Space_Mono'] mb-6">
          SHOWING {filtered.length} OF {spacecraftData.length} SPACECRAFT
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5 mb-8">
          <AnimatePresence mode="popLayout">
            {filtered.map((sc, i) => (
              <motion.div
                key={sc.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ delay: i * 0.04 }}
                onClick={() => setSelected(sc)}
                className="group cursor-pointer bg-gradient-to-br from-[#050d1a] to-[#020812] border border-blue-900/40 rounded-2xl overflow-hidden hover:border-blue-500/60 transition-all duration-400 hover:-translate-y-2 hover:shadow-2xl hover:shadow-blue-900/30"
              >
                {/* 3D Model */}
                <div
                  className="h-44 flex items-center justify-center relative overflow-hidden"
                  style={{
                    background: `radial-gradient(ellipse at center, ${sc.imageColor}22 0%, #020812 70%)`,
                  }}
                >
                  <SpacecraftModel3D type={sc.category} color={sc.imageColor} />
                  <div className="absolute top-3 right-3">
                    <span
                      className={`text-xs font-['Space_Mono'] px-2 py-0.5 rounded-full ${
                        sc.status === "Active"
                          ? "bg-green-900/60 border border-green-600/40 text-green-300"
                          : sc.status.includes("Development")
                          ? "bg-yellow-900/60 border border-yellow-600/40 text-yellow-300"
                          : "bg-red-900/60 border border-red-600/40 text-red-300"
                      }`}
                    >
                      {sc.status}
                    </span>
                  </div>
                  <div className="absolute bottom-2 left-3 text-xs font-['Space_Mono'] text-blue-400/60">
                    {sc.launchYear}
                  </div>
                </div>

                {/* Info */}
                <div className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-['Orbitron'] text-white text-sm font-bold group-hover:text-blue-300 transition-colors leading-tight">
                      {sc.name}
                    </h3>
                  </div>
                  <div className="text-blue-400 text-xs font-['Space_Mono'] mb-2">{sc.agency}</div>
                  <div className="text-gray-400 text-xs font-['Exo_2'] line-clamp-2 mb-3">
                    {sc.mission}
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-['Exo_2'] px-2 py-0.5 rounded-full bg-blue-900/30 border border-blue-700/30 text-blue-300 capitalize">
                      {sc.category}
                    </span>
                    <span className="text-xs text-gray-500 font-['Exo_2']">{sc.country}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-20 text-gray-500 font-['Exo_2']">
            No spacecraft found matching your filters.
          </div>
        )}
      </div>

      {/* Detail Modal */}
      <AnimatePresence>
        {selected && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
            onClick={() => setSelected(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 40 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 40 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-4xl max-h-[90vh] overflow-y-auto bg-[#050d1a] border border-blue-700/40 rounded-3xl"
            >
              {/* Modal Header */}
              <div
                className="relative h-56 flex items-center justify-center overflow-hidden rounded-t-3xl"
                style={{
                  background: `radial-gradient(ellipse at center, ${selected.imageColor}40 0%, #020812 70%)`,
                }}
              >
                <SpacecraftModel3D type={selected.category} color={selected.imageColor} />
                <button
                  onClick={() => setSelected(null)}
                  className="absolute top-4 right-4 w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors"
                >
                  ✕
                </button>
                <div className="absolute bottom-4 left-6">
                  <div className="text-xs font-['Space_Mono'] text-blue-400 mb-1">{selected.agency} · {selected.country}</div>
                  <h2 className="font-['Orbitron'] text-white text-2xl font-bold">{selected.name}</h2>
                </div>
              </div>

              {/* Modal Body */}
              <div className="p-6 space-y-6">
                {/* Status bar */}
                <div className="flex flex-wrap gap-3">
                  {[
                    { label: "Type", val: selected.type },
                    { label: "Launch Year", val: String(selected.launchYear) },
                    { label: "Status", val: selected.status },
                    { label: "Destination", val: selected.destination || "N/A" },
                  ].map((item) => (
                    <div key={item.label} className="bg-blue-900/20 border border-blue-700/30 rounded-xl px-4 py-3 flex-1 min-w-[120px]">
                      <div className="text-gray-500 text-xs font-['Exo_2'] mb-1">{item.label}</div>
                      <div className="text-white text-sm font-['Space_Mono']">{item.val}</div>
                    </div>
                  ))}
                </div>

                <div>
                  <h3 className="font-['Orbitron'] text-blue-300 text-sm font-bold mb-2">MISSION</h3>
                  <p className="text-gray-400 font-['Exo_2'] text-sm leading-relaxed">{selected.mission}</p>
                </div>

                <div>
                  <h3 className="font-['Orbitron'] text-blue-300 text-sm font-bold mb-2">DESCRIPTION</h3>
                  <p className="text-gray-300 font-['Exo_2'] text-sm leading-relaxed">{selected.description}</p>
                </div>

                {/* Specs */}
                {(selected.dimensions || selected.mass) && (
                  <div>
                    <h3 className="font-['Orbitron'] text-blue-300 text-sm font-bold mb-3">SPECIFICATIONS</h3>
                    <div className="grid grid-cols-2 gap-3">
                      {selected.dimensions && (
                        <div className="bg-blue-950/30 rounded-xl p-3 border border-blue-800/30">
                          <div className="text-gray-500 text-xs font-['Exo_2'] mb-1">Dimensions</div>
                          <div className="text-white text-xs font-['Space_Mono']">{selected.dimensions}</div>
                        </div>
                      )}
                      {selected.mass && (
                        <div className="bg-blue-950/30 rounded-xl p-3 border border-blue-800/30">
                          <div className="text-gray-500 text-xs font-['Exo_2'] mb-1">Mass</div>
                          <div className="text-white text-xs font-['Space_Mono']">{selected.mass}</div>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Features */}
                <div>
                  <h3 className="font-['Orbitron'] text-blue-300 text-sm font-bold mb-3">KEY FEATURES</h3>
                  <div className="flex flex-wrap gap-2">
                    {selected.features.map((f) => (
                      <span key={f} className="text-xs font-['Exo_2'] px-3 py-1.5 rounded-full bg-blue-900/30 border border-blue-700/30 text-blue-300">
                        {f}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Achievements */}
                <div>
                  <h3 className="font-['Orbitron'] text-blue-300 text-sm font-bold mb-3">NOTABLE ACHIEVEMENTS</h3>
                  <ul className="space-y-2">
                    {selected.notableAchievements.map((a, i) => (
                      <li key={i} className="flex items-start gap-3 text-gray-300 font-['Exo_2'] text-sm">
                        <span className="w-5 h-5 rounded-full bg-blue-700/40 flex items-center justify-center text-blue-300 text-xs flex-shrink-0 mt-0.5">★</span>
                        {a}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
