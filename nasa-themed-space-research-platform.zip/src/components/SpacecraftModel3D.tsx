import { useRef } from "react";
import { motion } from "framer-motion";

interface SpacecraftModel3DProps {
  type: string;
  color: string;
  name?: string;
}

// CSS 3D spacecraft models using pure CSS/SVG + animation
export default function SpacecraftModel3D({ type, color }: SpacecraftModel3DProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  const renderModel = () => {
    switch (type) {
      case "probe":
        return <ProbeModel color={color} />;
      case "crewed":
        return <CrewedModel color={color} />;
      case "telescope":
        return <TelescopeModel color={color} />;
      case "robotic":
        return <RoverModel color={color} />;
      case "satellite":
        return <SatelliteModel color={color} />;
      case "station":
        return <StationModel color={color} />;
      case "lander":
        return <LanderModel color={color} />;
      default:
        return <ProbeModel color={color} />;
    }
  };

  return (
    <div ref={containerRef} className="w-full h-full flex items-center justify-center">
      <motion.div
        animate={{ rotateY: 360 }}
        transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
        style={{ transformStyle: "preserve-3d" }}
        className="relative"
      >
        {renderModel()}
      </motion.div>
    </div>
  );
}

function ProbeModel({ color }: { color: string }) {
  return (
    <svg viewBox="0 0 200 200" className="w-40 h-40 drop-shadow-2xl">
      {/* Dish */}
      <ellipse cx="100" cy="70" rx="55" ry="12" fill={color} opacity="0.9" />
      <ellipse cx="100" cy="65" rx="55" ry="12" fill={color} />
      <ellipse cx="100" cy="63" rx="40" ry="8" fill="white" opacity="0.2" />
      {/* Body */}
      <rect x="88" y="70" width="24" height="40" rx="4" fill={color} />
      {/* Solar panels */}
      <rect x="20" y="85" width="68" height="12" rx="2" fill="#1a3a5c" opacity="0.9" />
      <rect x="112" y="85" width="68" height="12" rx="2" fill="#1a3a5c" opacity="0.9" />
      {/* Panel details */}
      {[28,38,48,58,68].map(x => <line key={x} x1={x} y1={85} x2={x} y2={97} stroke="#4a90d9" strokeWidth="1" opacity="0.6" />)}
      {[120,130,140,150,160,170].map(x => <line key={x} x1={x} y1={85} x2={x} y2={97} stroke="#4a90d9" strokeWidth="1" opacity="0.6" />)}
      {/* Antenna */}
      <line x1="100" y1="42" x2="100" y2="63" stroke="silver" strokeWidth="2" />
      {/* RTG */}
      <rect x="82" y="108" width="10" height="24" rx="2" fill="#888" />
      <circle cx="100" cy="90" r="6" fill="white" opacity="0.4" />
    </svg>
  );
}

function CrewedModel({ color }: { color: string }) {
  return (
    <svg viewBox="0 0 200 200" className="w-40 h-40 drop-shadow-2xl">
      {/* Main body (capsule) */}
      <ellipse cx="100" cy="75" rx="30" ry="18" fill={color} />
      <rect x="70" y="75" width="60" height="50" rx="2" fill={color} />
      {/* Heat shield */}
      <ellipse cx="100" cy="125" rx="32" ry="10" fill="#8B4513" />
      {/* Windows */}
      <circle cx="88" cy="78" r="7" fill="#87CEEB" opacity="0.8" />
      <circle cx="112" cy="78" r="7" fill="#87CEEB" opacity="0.8" />
      <circle cx="88" cy="78" r="4" fill="white" opacity="0.3" />
      <circle cx="112" cy="78" r="4" fill="white" opacity="0.3" />
      {/* Solar panels */}
      <rect x="18" y="90" width="52" height="14" rx="2" fill="#1a3a5c" />
      <rect x="130" y="90" width="52" height="14" rx="2" fill="#1a3a5c" />
      {[26,36,46,56].map(x => <line key={x} x1={x} y1={90} x2={x} y2={104} stroke="#4a90d9" strokeWidth="1" opacity="0.6" />)}
      {[138,148,158,168].map(x => <line key={x} x1={x} y1={90} x2={x} y2={104} stroke="#4a90d9" strokeWidth="1" opacity="0.6" />)}
      {/* Thrusters */}
      <rect x="75" y="122" width="10" height="14" rx="2" fill="#555" />
      <rect x="115" y="122" width="10" height="14" rx="2" fill="#555" />
      {/* NASA Stripe */}
      <rect x="70" y="100" width="60" height="5" fill="white" opacity="0.3" />
      <text x="100" y="104" textAnchor="middle" fontSize="4" fill="white" fontFamily="Orbitron">NASA</text>
    </svg>
  );
}

function TelescopeModel({ color }: { color: string }) {
  return (
    <svg viewBox="0 0 200 200" className="w-44 h-44 drop-shadow-2xl">
      {/* Main tube */}
      <rect x="72" y="50" width="56" height="100" rx="8" fill={color} opacity="0.9" />
      {/* Mirror housing */}
      <ellipse cx="100" cy="148" rx="28" ry="8" fill={color} />
      <ellipse cx="100" cy="148" rx="22" ry="5" fill="white" opacity="0.3" />
      {/* Front aperture */}
      <ellipse cx="100" cy="50" rx="28" ry="8" fill="#222" />
      <ellipse cx="100" cy="50" rx="20" ry="5" fill="#1a3a5c" opacity="0.7" />
      {/* Solar panels */}
      <rect x="8" y="80" width="64" height="20" rx="3" fill="#1a3a5c" />
      <rect x="128" y="80" width="64" height="20" rx="3" fill="#1a3a5c" />
      {[16,28,40,52,62].map(x => <line key={x} x1={x} y1={80} x2={x} y2={100} stroke="#4a90d9" strokeWidth="1.5" opacity="0.7" />)}
      {[136,148,160,172].map(x => <line key={x} x1={x} y1={80} x2={x} y2={100} stroke="#4a90d9" strokeWidth="1.5" opacity="0.7" />)}
      {/* Body details */}
      <rect x="80" y="65" width="40" height="3" rx="1" fill="white" opacity="0.2" />
      <rect x="80" y="120" width="40" height="3" rx="1" fill="white" opacity="0.2" />
      {/* Antenna */}
      <line x1="140" y1="50" x2="165" y2="35" stroke="silver" strokeWidth="2" />
      <circle cx="165" cy="33" r="3" fill="silver" />
    </svg>
  );
}

function RoverModel({ color }: { color: string }) {
  return (
    <svg viewBox="0 0 200 180" className="w-44 h-36 drop-shadow-2xl">
      {/* Body */}
      <rect x="55" y="60" width="90" height="50" rx="6" fill={color} />
      {/* Solar panel on top */}
      <rect x="50" y="40" width="100" height="20" rx="3" fill="#1a3a5c" />
      {[60,72,84,96,108,120,130,140].map(x => <line key={x} x1={x} y1={40} x2={x} y2={60} stroke="#4a90d9" strokeWidth="1" opacity="0.6" />)}
      {/* Mast/camera */}
      <rect x="120" y="25" width="4" height="35" fill="silver" />
      <circle cx="122" cy="23" r="6" fill="#333" />
      <circle cx="122" cy="23" r="3" fill="#87CEEB" opacity="0.8" />
      {/* Wheels (6 wheels like Perseverance) */}
      {[65, 95, 125].map(x => (
        <g key={x}>
          <ellipse cx={x} cy={120} rx="12" ry="16" fill="#555" />
          <ellipse cx={x} cy={120} rx="8" ry="12" fill="#333" />
          <line x1={x-8} y1={120} x2={x+8} y2={120} stroke="#888" strokeWidth="1.5" />
          <line x1={x} y1={108} x2={x} y2={132} stroke="#888" strokeWidth="1.5" />
        </g>
      ))}
      {/* Arm */}
      <line x1="55" y1="85" x2="30" y2="100" stroke="silver" strokeWidth="3" />
      <circle cx="28" cy="102" r="5" fill="#888" />
      {/* Body details */}
      <rect x="62" y="67" width="20" height="12" rx="2" fill="white" opacity="0.15" />
      <rect x="87" y="67" width="20" height="12" rx="2" fill="white" opacity="0.15" />
      <text x="100" y="95" textAnchor="middle" fontSize="7" fill="white" opacity="0.7" fontFamily="Orbitron">ROVER</text>
    </svg>
  );
}

function SatelliteModel({ color }: { color: string }) {
  return (
    <svg viewBox="0 0 200 200" className="w-36 h-36 drop-shadow-2xl">
      {/* Central sphere */}
      <circle cx="100" cy="100" r="28" fill={color} />
      <circle cx="100" cy="100" r="20" fill="white" opacity="0.15" />
      <circle cx="92" cy="92" r="8" fill="white" opacity="0.2" />
      {/* Antennas */}
      <line x1="100" y1="72" x2="100" y2="45" stroke="silver" strokeWidth="2" />
      <circle cx="100" cy="43" r="3" fill="silver" />
      <line x1="100" y1="128" x2="100" y2="155" stroke="silver" strokeWidth="2" />
      <circle cx="100" cy="157" r="3" fill="silver" />
      {/* Solar panels */}
      <rect x="15" y="86" width="57" height="28" rx="3" fill="#1a3a5c" />
      <rect x="128" y="86" width="57" height="28" rx="3" fill="#1a3a5c" />
      {[23,33,43,53,63].map(x => <line key={x} x1={x} y1={86} x2={x} y2={114} stroke="#4a90d9" strokeWidth="1" opacity="0.6" />)}
      {[136,146,156,166,176].map(x => <line key={x} x1={x} y1={86} x2={x} y2={114} stroke="#4a90d9" strokeWidth="1" opacity="0.6" />)}
      {/* Stripes on sphere */}
      <circle cx="100" cy="100" r="28" fill="none" stroke="white" strokeWidth="0.5" opacity="0.4" />
    </svg>
  );
}

function StationModel({ color }: { color: string }) {
  return (
    <svg viewBox="0 0 260 160" className="w-56 h-36 drop-shadow-2xl">
      {/* Main truss */}
      <rect x="20" y="73" width="220" height="14" rx="3" fill="#888" />
      {/* Central modules */}
      <rect x="100" y="58" width="60" height="44" rx="6" fill={color} />
      <rect x="90" y="64" width="80" height="32" rx="4" fill={color} opacity="0.8" />
      {/* Additional modules */}
      <rect x="72" y="65" width="30" height="30" rx="5" fill={color} opacity="0.7" />
      <rect x="158" y="65" width="30" height="30" rx="5" fill={color} opacity="0.7" />
      {/* Solar panel arrays */}
      <rect x="22" y="52" width="70" height="16" rx="2" fill="#1a3a5c" />
      <rect x="22" y="92" width="70" height="16" rx="2" fill="#1a3a5c" />
      <rect x="168" y="52" width="70" height="16" rx="2" fill="#1a3a5c" />
      <rect x="168" y="92" width="70" height="16" rx="2" fill="#1a3a5c" />
      {[30,40,50,60,70,80].map(x => <line key={x} x1={x} y1={52} x2={x} y2={68} stroke="#4a90d9" strokeWidth="1" opacity="0.6" />)}
      {[30,40,50,60,70,80].map(x => <line key={x} x1={x} y1={92} x2={x} y2={108} stroke="#4a90d9" strokeWidth="1" opacity="0.6" />)}
      {[176,186,196,206,216,226].map(x => <line key={x} x1={x} y1={52} x2={x} y2={68} stroke="#4a90d9" strokeWidth="1" opacity="0.6" />)}
      {[176,186,196,206,216,226].map(x => <line key={x} x1={x} y1={92} x2={x} y2={108} stroke="#4a90d9" strokeWidth="1" opacity="0.6" />)}
      {/* Docking port */}
      <rect x="125" y="42" width="10" height="16" rx="2" fill="#aaa" />
      {/* Windows */}
      <circle cx="116" cy="80" r="5" fill="#87CEEB" opacity="0.7" />
      <circle cx="130" cy="80" r="5" fill="#87CEEB" opacity="0.7" />
      <circle cx="144" cy="80" r="5" fill="#87CEEB" opacity="0.7" />
    </svg>
  );
}

function LanderModel({ color }: { color: string }) {
  return (
    <svg viewBox="0 0 200 200" className="w-40 h-40 drop-shadow-2xl">
      {/* Descent stage */}
      <polygon points="75,120 125,120 140,155 60,155" fill={color} opacity="0.8" />
      {/* Ascent module */}
      <rect x="82" y="75" width="36" height="48" rx="5" fill={color} />
      <ellipse cx="100" cy="75" rx="18" ry="8" fill={color} />
      <ellipse cx="100" cy="72" rx="14" ry="5" fill="white" opacity="0.25" />
      {/* Legs */}
      <line x1="65" y1="135" x2="40" y2="168" stroke="#888" strokeWidth="4" />
      <line x1="135" y1="135" x2="160" y2="168" stroke="#888" strokeWidth="4" />
      <line x1="75" y1="148" x2="50" y2="175" stroke="#888" strokeWidth="2.5" />
      <line x1="125" y1="148" x2="150" y2="175" stroke="#888" strokeWidth="2.5" />
      {/* Foot pads */}
      <ellipse cx="40" cy="170" rx="10" ry="4" fill="#666" />
      <ellipse cx="160" cy="170" rx="10" ry="4" fill="#666" />
      {/* Engine nozzle */}
      <polygon points="88,155 112,155 118,172 82,172" fill="#555" />
      {/* Antenna */}
      <line x1="100" y1="67" x2="100" y2="48" stroke="silver" strokeWidth="2" />
      <circle cx="100" cy="46" r="4" fill="white" opacity="0.8" />
      {/* Foil insulation */}
      <rect x="82" y="90" width="36" height="8" fill="#FFD700" opacity="0.6" />
      {/* Window */}
      <circle cx="100" cy="85" r="8" fill="#87CEEB" opacity="0.7" />
      <circle cx="100" cy="85" r="4" fill="white" opacity="0.3" />
    </svg>
  );
}
