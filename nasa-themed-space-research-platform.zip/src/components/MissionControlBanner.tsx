import { useState, useEffect } from "react";
import { motion } from "framer-motion";

export default function MissionControlBanner() {
  const [time, setTime] = useState(new Date());
  const [tick, setTick] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setTime(new Date());
      setTick((t) => t + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const formatUTC = (d: Date) =>
    d.toUTCString().replace("GMT", "UTC").split(" ").slice(0, 5).join(" ");

  const missionData = [
    { label: "ISS ALTITUDE", value: `${(408 + Math.sin(tick / 60) * 2).toFixed(1)} km` },
    { label: "ISS SPEED", value: "7.66 km/s" },
    { label: "ISS CREW", value: "7 ASTRONAUTS" },
    { label: "PERSEVERANCE SOL", value: `SOL ${1100 + Math.floor(tick / 86400)}` },
    { label: "VOYAGER 1 DIST", value: "24.2B km" },
    { label: "JWST STATUS", value: "NOMINAL" },
    { label: "ACTIVE MISSIONS", value: "250+" },
    { label: "MISSION T+", value: `${Math.floor(tick / 3600)}H ${Math.floor((tick % 3600) / 60)}M ${tick % 60}S` },
  ];

  return (
    <div className="relative bg-[#020812] border-y border-blue-900/30 overflow-hidden py-4">
      {/* Scanline effect */}
      <div className="absolute inset-0 pointer-events-none opacity-5"
        style={{
          backgroundImage: "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,100,255,0.3) 2px, rgba(0,100,255,0.3) 4px)",
        }}
      />

      <div className="max-w-7xl mx-auto px-4">
        {/* Top bar */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              <span className="font-['Space_Mono'] text-green-400 text-xs">MISSION CONTROL LIVE</span>
            </div>
          </div>
          <div className="font-['Space_Mono'] text-blue-400 text-xs">
            {formatUTC(time)}
          </div>
        </div>

        {/* Data panels */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          {missionData.map((item, i) => (
            <motion.div
              key={item.label}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: i * 0.05 }}
              className="bg-blue-950/20 border border-blue-800/30 rounded-lg px-3 py-2"
            >
              <div className="text-gray-600 font-['Space_Mono'] text-[9px] tracking-wider mb-1">
                {item.label}
              </div>
              <div className="text-blue-300 font-['Space_Mono'] text-xs font-bold">
                {item.value}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Scrolling ticker */}
        <div className="mt-4 overflow-hidden relative h-6">
          <motion.div
            animate={{ x: ["100%", "-200%"] }}
            transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
            className="absolute whitespace-nowrap flex items-center gap-8"
          >
            {[
              "🚀 Artemis III Moon landing planned for 2027",
              "🪐 Cassini discovered water plumes on Enceladus",
              "🔭 JWST detected CO₂ on exoplanet WASP-39b",
              "🌕 Chandrayaan-3 landed at Moon's south pole — Aug 23, 2023",
              "🛸 Voyager 1 is the farthest human-made object from Earth",
              "🔴 Perseverance rover has collected 50+ rock samples on Mars",
              "🌌 The universe is 13.8 billion years old — confirmed by WMAP & Planck",
              "⭐ The Milky Way contains 100-400 billion stars",
              "🌍 ISS has been continuously inhabited since November 2, 2000",
            ].map((msg) => (
              <span key={msg} className="text-gray-500 font-['Exo_2'] text-xs">
                {msg}
              </span>
            ))}
          </motion.div>
        </div>
      </div>
    </div>
  );
}
